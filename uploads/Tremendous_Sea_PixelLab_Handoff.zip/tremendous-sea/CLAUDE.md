# Tremendous Sea — Instructions for the AI Assistant

You are helping turn **Tremendous Sea**, a working roguelite deckbuilder, into a finished-looking pixel art game. All gameplay already works. Your job is the art and the presentation: generate assets with the PixelLab MCP tools and wire them into the Phaser renderer.

## Read these first

1. `docs/GAME_OVERVIEW.md`: what the game is, how the code works, and where art plugs in.
2. `docs/ART_DIRECTION.md`: the complete, approved visual style and every design. Follow it exactly.
3. `docs/ASSET_LIST.md`: every asset to make, with file name, size, animations and priority. Use it as your checklist.

## Rules

- **Do not change gameplay.** `data.js`, `engine.js` and `ui.js` hold the game's rules and are shared with a separate HTML build. Make visual changes in `phaser-scene.js`, plus any new rendering files you add. If a visual feature truly needs a logic change, stop and ask the creator first.
- **Never invent character appearances.** Every captain, crew member, ship and shopkeeper look is already decided in `ART_DIRECTION.md`. If something isn't specified, ask.
- **Ask before deviating** from the art direction, the build order, or the asset specs.
- **Never use the word "barnacle"** anywhere in the game, including asset names and descriptions.
- **Name new things with a candy motif.**
- **Pixel-perfect output:** never upscale or resize generated sprites. Keep them at the exact pixel size in `ASSET_LIST.md`. The game scales the whole screen up evenly instead.

## Working efficiently (generations cost money)

1. **Lock the style before anything else.** Phase 0 produces one approved reference character. Use it as the style reference for every later generation.
2. **Static first, then animate.** Get a still image approved before spending generations on animation frames.
3. **Test in the game before batching.** Wire each new kind of asset into the game and check it on screen before generating the rest of that kind.
4. **Change one thing at a time** when a generation misses, so you learn what fixed it.
5. **Reuse instead of regenerate.** Group enemies use one sprite with color shifts done in code. Gear icon rims, card rarity gems and similar recolors are done in code from a single base asset.
6. **Show the creator results at the end of each phase** and wait for approval before starting the next one.

## Build phases

**Phase 0: Foundation**
- Rework `phaser-scene.js` to a 640×360 base resolution with pixel-perfect integer scaling (see `GAME_OVERVIEW.md`, "Resolution").
- Build a sprite system: load sprite sheets when they exist, fall back to the current placeholder rectangles when they don't, and play idle, attack, hurt and death animations at the existing hooks.
- Load the fonts: Pixelify Sans, Nunito, IM Fell English SC.
- Generate Branch's idle still and get the creator's approval. That image becomes the style reference.

**Phase 1: Vertical slice (Branch, Act 1)**
- Branch: all animations.
- The Kindleroot deck background with the Act 1 sky and sea.
- The 7 Act 1 commons, then the 6 Act 1 elites, then the 3 Act 1 bosses and their arenas.
- Core UI: Branch's card frame, card back, card-type icons, rarity gems, HP and Block bars, energy orb, pile icons, End Turn button, damage numbers.
- Act 1 map screen and map node icons.
- Finished means a full Act 1 run with Branch looks like a real game.

**Phase 2: The other captains**
- Riley (three stances) with the Stage deck and her card frame; Broderick (with Full Moon) with the Howling Shell deck and his card frame.
- Riley's Clarity gauge and stance banners; Broderick's bullet clip display.

**Phase 3: Act 2**
- Act 2 sky and sea, map, commons, elites, bosses and arenas, and the King in Green.

**Phase 4: Act 3**
- Act 3 sky and sea, map, commons, elites, bosses and arenas, including every extra boss and elite form.

**Phase 5: Screens and remaining assets**
- Title screen and logo, captain select with portraits, the F&J Emporium shop, the oasis, event backdrops, victory and defeat banners, the pause menu, the curse card frame, 15 crew portraits, and 61 Gear icons.

## Running the game

Serve the folder with any static web server (for example `npx serve .`) and open `index.html`. The game is also deployed through GitHub Pages from this folder's root.
