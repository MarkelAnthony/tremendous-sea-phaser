# Tremendous Sea — Handoff Package

This folder holds the playable game plus everything an AI coding assistant needs to bring the art to life with PixelLab.

## What's inside

| File | Purpose |
|---|---|
| `CLAUDE.md` | Instructions the AI reads automatically: rules, efficient workflow, build phases |
| `docs/GAME_OVERVIEW.md` | How the game works and how the code is organized |
| `docs/ART_DIRECTION.md` | Every approved style decision and design |
| `docs/ASSET_LIST.md` | All 185 assets as a checklist, in build order, with exact sizes |
| `index.html`, `*.js` | The current, working game |
| `assets/` | Empty folders where generated art will go |

## Setup

1. **Unzip** this folder somewhere on your computer.
2. **Install Claude Code** (see claude.com/claude-code).
3. **Connect PixelLab** by following the instructions at pixellab.ai/mcp. This needs an active PixelLab subscription.
4. **Open this folder** in Claude Code and say:
   > Read CLAUDE.md and the docs folder, then start Phase 0.
5. **Approve each phase** when the AI shows you its results. It will stop and wait for you.

## Tips

- Phase 0 produces one reference image of Branch. Take your time approving it; every other asset copies its style.
- Phase 1 alone (Branch through all of Act 1) is the best measure of how long and how many generations the rest will take.
- To publish updates, upload the changed files (and the `assets` folder) to your GitHub repo as before.
